echo 'This is a test'; // This is a one-line c++ style comment
/* This is
    a multi line comment
    with yet another line of comment */
echo 'One Final Test'; # This is a one-line shell-style comment
# One more here
/* Multiline comment in between */ # yet another one
echo 'smth' # one # or two of us? :)
# Hey, I'm still here!
echo '// And this one is quite tough...' // Strip me!
echo "/* // ...let alone this one!**/"
