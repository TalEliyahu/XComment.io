echo 'This is a test'; 

echo 'One Final Test'; 

 
echo 'smth' 

echo '// And this one is quite tough...' 
echo "/* // ...let alone this one!**/"
